<a {{$attributes}}>
    {{$slot}}
</a>
