<div>
    <!-- Nothing worth having comes easy. - Theodore Roosevelt -->
   
    {{$slot}}
</div>
