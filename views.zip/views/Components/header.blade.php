<div>
    <!-- Well begun is half done. - Aristotle -->
   {{$slot}}
</div>
