<li {{$attributes}}>{{$slot}}</li>
