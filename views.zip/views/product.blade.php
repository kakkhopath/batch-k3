<x-layout>
    <h1>Product: page</h1>
    <x-modal>
        <x-slot:heading>
            Product Modal Headline
        </x-slot>
        <x-slot:title>Product modal title</x-slot:title>
     
            This is  Content for product
     
        <x-slot:closeButton>
            Close 
        </x-slot>
        <x-slot:savebutton>
            Save Changes
        </x-slot>
    </x-modal>
</x-layout>
