<x-layout>
    <h1>This is my home page</h1>

   <x-list-item>List data</x-list-item>
   <x-list-item>List data</x-list-item>
   <x-list-item>List data</x-list-item>

   <x-navlink href="/product">Nav Item</x-navlink>

@php 
    $productId = '1';
    $content = " Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt eaque consequuntur quam asperiores adipisci explicabo reprehenderit dolorum quia ipsum necessitatibus ab consectetur veniam corrupti, culpa est a labore aspernatur ducimus.";
@endphp 

<x-modal>
    <x-slot:heading>
        Heading 
        <x-slot:productId>{{$productId}}</x-slot:productId>
    </x-slot>
    <x-slot:title>Home modal title</x-slot:title>
 
        {{$content}}
       
 
    <x-slot:closeButton>
        Close Button
    </x-slot>
    <x-slot:savebutton>
        Save Button
    </x-slot>
</x-modal>
   
</x-layout>
